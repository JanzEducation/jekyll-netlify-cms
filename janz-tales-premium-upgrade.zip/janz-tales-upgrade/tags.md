---
layout: default
title: Tags
permalink: /tags/
---
{% assign all_tags = site.posts | map: "tags" | join: "," | split: "," | uniq | sort %}
<div class="container">
  <nav class="breadcrumb" aria-label="Breadcrumb">
    <a href="{{ '/' | relative_url }}">Home</a>
    <span class="sep">/</span>
    <span>Tags</span>
  </nav>

  {% for tag in all_tags %}
    {% assign clean_tag = tag | strip %}
    {% if clean_tag != "" %}
    {% assign tag_posts = site.posts | where_exp: "p", "p.tags contains clean_tag" %}
    <div id="{{ clean_tag | slugify }}" class="section-heading">
      <h2>#{{ clean_tag }}</h2>
      <span class="view-all">{{ tag_posts.size }} {% if tag_posts.size == 1 %}story{% else %}stories{% endif %}</span>
    </div>
    <div class="news-grid">
      {% for post in tag_posts %}
      <article class="card reveal">
        <a href="{{ post.url | relative_url }}" class="thumb">
          <span class="cat-tag">{{ post.category | default: "News" }}</span>
          {% if post.image %}<img src="{{ post.image | relative_url }}" alt="{{ post.title }}" loading="lazy">{% endif %}
        </a>
        <div class="card-body">
          <h3><a href="{{ post.url | relative_url }}">{{ post.title }}</a></h3>
          <span class="trend-meta">{{ post.date | date: "%b %d, %Y" }}</span>
        </div>
      </article>
      {% endfor %}
    </div>
    {% endif %}
  {% endfor %}
</div>
