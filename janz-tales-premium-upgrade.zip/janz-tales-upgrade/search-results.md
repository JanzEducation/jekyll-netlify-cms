---
layout: default
title: Search Results
permalink: /search-results/
---
<div class="container">
  <nav class="breadcrumb" aria-label="Breadcrumb">
    <a href="{{ '/' | relative_url }}">Home</a>
    <span class="sep">/</span>
    <span>Search</span>
  </nav>

  <div class="section-heading"><h2 id="search-heading">Search Results</h2></div>

  <div id="search-results-grid" class="news-grid"></div>
  <p id="search-empty" style="display:none;color:var(--c-text-muted);">No stories matched your search. Try a different keyword.</p>
</div>

<script>
(function () {
  var params = new URLSearchParams(window.location.search);
  var q = (params.get('q') || '').trim().toLowerCase();
  var heading = document.getElementById('search-heading');
  var grid = document.getElementById('search-results-grid');
  var empty = document.getElementById('search-empty');
  heading.textContent = q ? 'Results for "' + q + '"' : 'Search Results';

  if (!q) { empty.style.display = 'block'; return; }

  fetch('{{ "/search.json" | relative_url }}')
    .then(function (res) { return res.json(); })
    .then(function (posts) {
      var matches = posts.filter(function (p) {
        return (p.title + ' ' + p.excerpt + ' ' + p.category).toLowerCase().indexOf(q) !== -1;
      });
      if (!matches.length) { empty.style.display = 'block'; return; }
      grid.innerHTML = matches.map(function (p) {
        return '<article class="card reveal is-visible">' +
          '<a href="' + p.url + '" class="thumb"><span class="cat-tag">' + p.category + '</span>' +
          (p.image ? '<img src="' + p.image + '" alt="' + p.title + '" loading="lazy">' : '') + '</a>' +
          '<div class="card-body"><h3><a href="' + p.url + '">' + p.title + '</a></h3>' +
          '<p class="excerpt">' + p.excerpt + '</p>' +
          '<span class="trend-meta">' + p.date + '</span></div></article>';
      }).join('');
    })
    .catch(function () { empty.style.display = 'block'; });
})();
</script>
