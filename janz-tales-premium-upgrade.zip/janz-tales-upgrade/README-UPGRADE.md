# JANZ TALES — Premium Design Upgrade

This package upgrades the **front-end design only** of your existing
`jekyll-netlify-cms` repository. It does not touch your posts, uploads,
Netlify CMS config, or GitHub Pages setup.

## ⚠️ Important — read before uploading

I don't have direct access to your GitHub repository or its current file
contents, so this package was built as a **standalone drop-in upgrade**,
not a diff of your actual repo. Copy the files below into your existing
project; do not upload this whole zip over your repo, or you'll overwrite
folders you asked to keep (`_posts/`, `img/uploads/`, `admin/`, etc. are
**not** included here for that exact reason).

## What's inside this package

```
_layouts/default.html      → new master layout (header + main + footer)
_layouts/home.html         → homepage: hero, slider, news grid, categories
_layouts/post.html         → article page: breadcrumb, reading time, author box, related posts
_layouts/page.html         → simple layout for About/Contact/Privacy/Terms
_layouts/category.html     → auto-generated category listing pages
_includes/header.html      → sticky header, breaking ticker, search, mobile nav
_includes/footer.html      → footer, newsletter, back-to-top
_includes/sidebar.html     → trending, most read, tags, newsletter, ad slots
_includes/seo.html         → meta tags, Open Graph, Twitter Cards, JSON-LD, GA/AdSense hooks
assets/css/style.css       → full premium design system (black/white/red)
assets/js/main.js          → all interactivity, vanilla JS, no dependencies
index.md                   → new homepage (uses layout: home)
archive.md                 → "all posts" page
tags.md                    → tag index page
search-results.md          → client-side search results page
search.json                → Jekyll-generated JSON index used by search
category/*.md (16 files)   → one listing page per category in your nav
_config-additions.yml      → keys to MERGE into your existing _config.yml
```

## Step-by-step install

1. **Back up your repo** (or work on a new branch).
2. Copy `_layouts/*.html` into your existing `_layouts/` folder. This adds/overwrites
   `default.html`, `home.html`, `post.html`, `page.html`, `category.html` only —
   any other layout files you already have are untouched.
3. Copy `_includes/*.html` into your existing `_includes/` folder (adds
   `header.html`, `footer.html`, `sidebar.html`, `seo.html`).
4. Copy `assets/css/style.css` and `assets/js/main.js` into `assets/css/`
   and `assets/js/` (create those folders if they don't exist).
5. Replace your existing `index.md` with the one in this package — or, if your
   current `index.md` has content you want to keep, just make sure its front
   matter starts with `layout: home` and `permalink: /`.
6. Copy `archive.md`, `tags.md`, `search-results.md`, `search.json`, and the
   `category/` folder into the **root** of your repo.
7. Open your real `_config.yml` and merge in every key from
   `_config-additions.yml` (title, tagline, description, social, nav_categories,
   google_analytics_id, google_adsense_id, default_image). **Do not overwrite**
   your existing `_config.yml` — only add these keys.
8. Make sure `about.md`, `contact.md`, `privacy-policy.md`, and `terms.md` each
   have `layout: page` in their front matter (add that one line if it's missing)
   so they pick up the new design.
9. Commit and push. GitHub Pages will rebuild automatically.

## Post front matter your posts should use

Your existing posts in `_posts/` are untouched, but for the new design to show
category tags, images, breaking-news ticker items, and fact-check badges, add
these optional fields to a post's front matter (all optional, all with safe
fallbacks if omitted):

```yaml
---
title: "Your headline"
date: 2026-07-04 10:00:00 +0530
category: "Technology"
tags: [ai, smartphones, india]
image: /img/uploads/your-image.jpg
excerpt: "One or two sentence summary shown on cards and social shares."
author: "Reporter Name"
author_image: /img/uploads/author.jpg
author_bio: "Short one-line bio."
breaking: true        # shows in the ticker
fact_check: true       # shows the "Fact Checked" badge
---
```

## Optional: Netlify CMS fields

Your `admin/config.yml` was intentionally left untouched. If you'd like the
CMS editor UI to expose the new fields above (category, image, tags, breaking,
fact_check, author, author_image, author_bio), add matching `widget` fields to
the `posts` collection in `admin/config.yml` yourself, or ask me to draft that
separately — I kept it out of this package per your instructions not to modify
`admin/`.

## Design notes

- Colors: black `#0a0a0a`, white `#ffffff`, red `#e50914` — CSS variables at
  the top of `style.css`, easy to retint.
- Fonts: Fraunces (headlines), Inter (body), IBM Plex Mono (ticker/timestamps/labels),
  loaded from Google Fonts — swap the `@import` line in `style.css` if you'd
  rather self-host for max PageSpeed score.
- Dark/light mode is saved in `localStorage` and respects the visitor's OS
  preference on first visit.
- No Bootstrap, Tailwind, or React — pure HTML5, CSS3, vanilla JS, and Liquid,
  fully compatible with GitHub Pages' safe Jekyll build.
