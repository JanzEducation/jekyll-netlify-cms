/*!
 * JANZ TALES — main.js
 * Vanilla JS. No dependencies.
 */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    initTheme();
    initStickyHeader();
    initMobileNav();
    initSearchOverlay();
    initTicker();
    initSlider();
    initReadingProgress();
    initReadingTime();
    initBackToTop();
    initRevealOnScroll();
    initNewsletterForm();
    initLazyImages();
  });

  /* ---------------------------------------------------------- *
   * Dark / light mode
   * ---------------------------------------------------------- */
  function initTheme() {
    var root = document.documentElement;
    var toggleBtns = document.querySelectorAll('[data-theme-toggle]');
    var stored = safeGet('jt-theme');
    var prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    var initial = stored || (prefersDark ? 'dark' : 'light');
    root.setAttribute('data-theme', initial);

    toggleBtns.forEach(function (btn) {
      btn.addEventListener('click', function () {
        var current = root.getAttribute('data-theme');
        var next = current === 'dark' ? 'light' : 'dark';
        root.setAttribute('data-theme', next);
        safeSet('jt-theme', next);
      });
    });
  }

  function safeGet(key) {
    try { return window.localStorage.getItem(key); } catch (e) { return null; }
  }
  function safeSet(key, val) {
    try { window.localStorage.setItem(key, val); } catch (e) { /* ignore */ }
  }

  /* ---------------------------------------------------------- *
   * Sticky header shrink-on-scroll
   * ---------------------------------------------------------- */
  function initStickyHeader() {
    var header = document.querySelector('.site-header');
    if (!header) return;
    var lastY = window.scrollY;
    window.addEventListener('scroll', function () {
      var y = window.scrollY;
      if (y > 40) header.classList.add('is-scrolled');
      else header.classList.remove('is-scrolled');
      lastY = y;
    }, { passive: true });
  }

  /* ---------------------------------------------------------- *
   * Mobile hamburger nav
   * ---------------------------------------------------------- */
  function initMobileNav() {
    var hamburger = document.querySelector('.hamburger');
    var drawer = document.querySelector('.mobile-nav');
    var backdrop = document.querySelector('.mobile-nav-backdrop');
    var closeBtn = document.querySelector('[data-mobile-nav-close]');
    if (!hamburger || !drawer) return;

    function open() {
      drawer.classList.add('is-open');
      backdrop.classList.add('is-open');
      hamburger.classList.add('is-active');
      hamburger.setAttribute('aria-expanded', 'true');
      document.body.style.overflow = 'hidden';
    }
    function close() {
      drawer.classList.remove('is-open');
      backdrop.classList.remove('is-open');
      hamburger.classList.remove('is-active');
      hamburger.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
    }
    hamburger.addEventListener('click', function () {
      drawer.classList.contains('is-open') ? close() : open();
    });
    if (backdrop) backdrop.addEventListener('click', close);
    if (closeBtn) closeBtn.addEventListener('click', close);
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') close();
    });
  }

  /* ---------------------------------------------------------- *
   * Search overlay
   * ---------------------------------------------------------- */
  function initSearchOverlay() {
    var openBtns = document.querySelectorAll('[data-search-open]');
    var overlay = document.querySelector('.search-overlay');
    var closeBtn = document.querySelector('[data-search-close]');
    var input = document.querySelector('.search-box input');
    if (!overlay) return;

    function open() {
      overlay.classList.add('is-open');
      setTimeout(function () { if (input) input.focus(); }, 200);
    }
    function close() { overlay.classList.remove('is-open'); }

    openBtns.forEach(function (btn) { btn.addEventListener('click', open); });
    if (closeBtn) closeBtn.addEventListener('click', close);
    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) close();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') close();
      if ((e.key === '/' || (e.ctrlKey && e.key === 'k')) && document.activeElement.tagName !== 'INPUT') {
        e.preventDefault();
        open();
      }
    });
  }

  /* ---------------------------------------------------------- *
   * Breaking news ticker — duplicate content for seamless loop
   * ---------------------------------------------------------- */
  function initTicker() {
    var track = document.querySelector('.ticker-track');
    if (!track) return;
    var original = track.innerHTML;
    track.innerHTML = original + original;
  }

  /* ---------------------------------------------------------- *
   * Featured slider
   * ---------------------------------------------------------- */
  function initSlider() {
    var slider = document.querySelector('.slider');
    if (!slider) return;
    var track = slider.querySelector('.slider-track');
    var slides = Array.prototype.slice.call(slider.querySelectorAll('.slide'));
    var dotsWrap = slider.querySelector('.slider-dots');
    var prevBtn = slider.querySelector('.slider-arrow.prev');
    var nextBtn = slider.querySelector('.slider-arrow.next');
    if (!slides.length) return;

    var index = 0;
    var timer;

    slides.forEach(function (_, i) {
      var dot = document.createElement('button');
      dot.type = 'button';
      dot.setAttribute('aria-label', 'Go to slide ' + (i + 1));
      if (i === 0) dot.classList.add('is-active');
      dot.addEventListener('click', function () { goTo(i); });
      if (dotsWrap) dotsWrap.appendChild(dot);
    });

    function render() {
      track.style.transform = 'translateX(-' + (index * 100) + '%)';
      if (dotsWrap) {
        Array.prototype.forEach.call(dotsWrap.children, function (dot, i) {
          dot.classList.toggle('is-active', i === index);
        });
      }
    }
    function goTo(i) {
      index = (i + slides.length) % slides.length;
      render();
      restart();
    }
    function next() { goTo(index + 1); }
    function prev() { goTo(index - 1); }
    function restart() {
      clearInterval(timer);
      timer = setInterval(next, 6000);
    }

    if (nextBtn) nextBtn.addEventListener('click', next);
    if (prevBtn) prevBtn.addEventListener('click', prev);

    // touch swipe
    var startX = null;
    track.addEventListener('touchstart', function (e) { startX = e.touches[0].clientX; }, { passive: true });
    track.addEventListener('touchend', function (e) {
      if (startX === null) return;
      var diff = e.changedTouches[0].clientX - startX;
      if (Math.abs(diff) > 40) diff > 0 ? prev() : next();
      startX = null;
    });

    restart();
  }

  /* ---------------------------------------------------------- *
   * Reading progress bar (article pages)
   * ---------------------------------------------------------- */
  function initReadingProgress() {
    var bar = document.querySelector('.reading-progress');
    var article = document.querySelector('.article-body');
    if (!bar || !article) return;
    window.addEventListener('scroll', function () {
      var rect = article.getBoundingClientRect();
      var total = rect.height - window.innerHeight;
      var scrolled = Math.min(Math.max(-rect.top, 0), total);
      var pct = total > 0 ? (scrolled / total) * 100 : 0;
      bar.style.width = pct + '%';
    }, { passive: true });
  }

  /* ---------------------------------------------------------- *
   * Estimated reading time
   * ---------------------------------------------------------- */
  function initReadingTime() {
    var target = document.querySelector('[data-reading-time]');
    var article = document.querySelector('.article-body');
    if (!target || !article) return;
    var words = article.textContent.trim().split(/\s+/).length;
    var minutes = Math.max(1, Math.round(words / 200));
    target.textContent = minutes + ' min read';
  }

  /* ---------------------------------------------------------- *
   * Back to top button
   * ---------------------------------------------------------- */
  function initBackToTop() {
    var btn = document.querySelector('.back-to-top');
    if (!btn) return;
    window.addEventListener('scroll', function () {
      if (window.scrollY > 600) btn.classList.add('is-visible');
      else btn.classList.remove('is-visible');
    }, { passive: true });
    btn.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  /* ---------------------------------------------------------- *
   * Reveal-on-scroll animation
   * ---------------------------------------------------------- */
  function initRevealOnScroll() {
    var items = document.querySelectorAll('.reveal');
    if (!items.length) return;
    if (!('IntersectionObserver' in window)) {
      items.forEach(function (el) { el.classList.add('is-visible'); });
      return;
    }
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    items.forEach(function (el) { observer.observe(el); });
  }

  /* ---------------------------------------------------------- *
   * Newsletter form (static site — client-side confirmation only)
   * ---------------------------------------------------------- */
  function initNewsletterForm() {
    var forms = document.querySelectorAll('.newsletter-form');
    forms.forEach(function (form) {
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var input = form.querySelector('input[type="email"]');
        var btn = form.querySelector('button');
        if (!input || !input.value) return;
        var originalText = btn.textContent;
        btn.textContent = 'Subscribed ✓';
        btn.disabled = true;
        input.value = '';
        setTimeout(function () {
          btn.textContent = originalText;
          btn.disabled = false;
        }, 3000);
      });
    });
  }

  /* ---------------------------------------------------------- *
   * Native lazy loading fallback attribute assignment
   * ---------------------------------------------------------- */
  function initLazyImages() {
    var imgs = document.querySelectorAll('img:not([loading])');
    imgs.forEach(function (img) { img.setAttribute('loading', 'lazy'); });
  }
})();
