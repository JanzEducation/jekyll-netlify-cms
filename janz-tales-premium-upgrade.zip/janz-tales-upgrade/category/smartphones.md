---
layout: category
title: "Smartphones"
category: "Smartphones"
permalink: /category/smartphones/
---
