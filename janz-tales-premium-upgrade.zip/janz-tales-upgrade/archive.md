---
layout: default
title: Archive
permalink: /archive/
---
<div class="container">
  <nav class="breadcrumb" aria-label="Breadcrumb">
    <a href="{{ '/' | relative_url }}">Home</a>
    <span class="sep">/</span>
    <span>Archive</span>
  </nav>

  <div class="section-heading"><h2>All Stories</h2></div>

  <div class="content-layout">
    <div class="main-col">
      <div class="news-grid">
        {% for post in site.posts %}
        <article class="card reveal">
          <a href="{{ post.url | relative_url }}" class="thumb">
            <span class="cat-tag">{{ post.category | default: "News" }}</span>
            {% if post.image %}<img src="{{ post.image | relative_url }}" alt="{{ post.title }}" loading="lazy">{% endif %}
          </a>
          <div class="card-body">
            <h3><a href="{{ post.url | relative_url }}">{{ post.title }}</a></h3>
            <p class="excerpt">{{ post.excerpt | strip_html | truncate: 90 }}</p>
            <span class="trend-meta">{{ post.date | date: "%b %d, %Y" }}</span>
          </div>
        </article>
        {% endfor %}
      </div>
    </div>
    {% include sidebar.html %}
  </div>
</div>
